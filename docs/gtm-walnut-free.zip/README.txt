GTM Walnut Free

Each .zip inside is one skill. On Claude.ai or Claude Desktop: Customize > Skills > Upload a skill, once per zip.
