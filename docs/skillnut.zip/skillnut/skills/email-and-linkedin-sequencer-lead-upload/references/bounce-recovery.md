# Bounce recovery: gateway-bounced leads into a LinkedIn sequence (option R)

Load this when the user picks option R. It takes people whose email was refused by their company's mail security gateway and gives them a second channel: a LinkedIn sequence. The email bounced; the person did not.

## The rule behind it

**In a niche market, never discard gateway bounces.** When the whole market is a few hundred or a few thousand accounts and each deal is large, every reachable person matters. A gateway bounce (Mimecast, Proofpoint, Barracuda and the like) means the address is real and a filter refused the mail. That person can still be reached on LinkedIn, and a list that bounced on email can still produce interested replies within days of moving to LinkedIn.

An invalid-address bounce is different: the mailbox does not exist. Those people need a corrected email or a LinkedIn URL found by other means; they are not what this mode moves by default.

## Pair it with the deliverability skill

The Email Deliverability Metrics and Dashboard skill maps which share of the user's recipients sit behind each gateway, which sending domains get through each one, and splits gateway bounces from invalid-address bounces. Run that first when it is available: its bounce autopsy tells you how big the recovery pool is and confirms the bounces are gateway refusals, not bad data. This mode then moves the people; that skill fixes the routing so fewer of them bounce next time.

## Step 1: find the gateway-bounced leads (read-only)

1. List the email campaigns in scope (the ones the user names, or all campaigns that sent in the window).
2. Pull the bounced leads. In Email Bison: a lead's status reads bounced, and every lead carries a mail-provider tag detected from its MX record (Google, Outlook, Zoho, Custom Mail Server, Mimecast, Proofpoint, Barracuda, Sophos and others). Page `GET /api/leads` to the true last page (15 per page regardless of what you ask) and filter on both.
3. Split them and report the counts: bounced behind a hard gateway, bounced on plain Google or Outlook, bounced with no tag. The first group is the recovery pool. Say the others plainly; do not fold them in.
4. Run the exclusions before anything moves:
   - Anyone who replied to any campaign, on any channel, including a neutral reply, stays out for good.
   - Customers and do-not-contact domains stay out.
   - Anyone already in a LinkedIn campaign for this client is listed by name; the user decides.
   - People with no LinkedIn profile URL cannot go to LinkedIn. Count them and offer a URL lookup (an enrichment tool that finds the profile from name and company) as a separate step.
5. Report the pool, for example (illustrative): *"Across your 6 campaigns, 340 leads bounced. 290 sit behind Mimecast or Proofpoint, 38 on plain Outlook, 12 untagged. After removing 4 who replied elsewhere and 1 customer, 285 are in the recovery pool; 261 have a LinkedIn URL. Nothing has moved."*

## Step 2: choose the route

| Route | When | How |
|---|---|---|
| The email tool's native LinkedIn integration | The email tool has one (Email Bison has a HeyReach integration) and the user wants the simplest path | Set up in the email tool's UI by the user; leads pushed from the email tool into a chosen LinkedIn campaign |
| This skill's LinkedIn track | No native integration, the user wants per-person notes and messages as variables, or wants the full QC | Build lists and a campaign in the LinkedIn tool by API (Stages 3 to 6, LinkedIn track) with the recovery pool as the CSV |

## Step 3 (native route): connect the email tool to the LinkedIn tool

The user does this in the email tool's UI; the skill walks them through it and never handles the key itself.

1. In the LinkedIn tool, create or copy an API key (in HeyReach it lives under Integrations). The user keeps it; never ask them to paste it into chat, and never print it.
2. In the email tool's integration settings, the user adds the LinkedIn tool's API key.
3. Pick the target LinkedIn campaign the bounced leads should land in.
4. Set the default field mappings: name, company, title, email and, above all, the LinkedIn profile URL. A lead without a profile URL cannot be worked on LinkedIn. Check the mapping on screen with the user before any push.
5. In the LinkedIn tool, configure the campaign before any lead arrives: the sender accounts (each connected and healthy), the sequence, and the messages. Copy belongs to the Copywriting Messaging skill and is frozen once the user approves it.
6. The target campaign stays in draft (or paused) until the user says start.

## Step 4: pilot, then push

1. **Show the plan first**: how many people, which campaign, which senders, which fields map where.
2. **Pilot about 10 people** on the user's explicit go. Read them back in the LinkedIn tool: each person present once, the right name, company and URL, variables filled.
3. **Already connected.** Run this skill's already-connected check (engine, LinkedIn: Already connected) on the pilot and then the full pool. Ask the user every time: message them or exclude them. Never default.
4. **Push the rest** on a second go, in batches, and read the counts back: pushed, added, failed. Failed people are named.
5. **Start** the LinkedIn campaign only when the user says start, per campaign.

## Step 5: QC and handover

- The reconcile line: bounced pulled = recovery pool + plain-mailbox bounces + untagged + excluded, and recovery pool = pushed + no URL + failed. Every person in exactly one bucket.
- Zero people in the LinkedIn campaign who replied anywhere, are customers, or sit on the do-not-contact list.
- No email hand-off step in the LinkedIn sequence for these people: the email already bounced, so a step that sends them back to the email tool wastes a touch and a bounce.
- The stop rule stated: a human reply on LinkedIn ends outreach on every channel (out-of-office excepted).
- What to watch: replies on the recovery campaign over the first week or two, compared with the main LinkedIn campaigns. If it works, make the push a standing step after every email campaign in that market.

## Safety

- Finding and counting is read-only. The push and the start are writes and each waits for the user to name it and say go.
- Never print the email tool's or the LinkedIn tool's key; if a key appears on screen in a recording or screenshot, tell the user to rotate it.
- Bounced people are never put back into an email campaign by this mode.
