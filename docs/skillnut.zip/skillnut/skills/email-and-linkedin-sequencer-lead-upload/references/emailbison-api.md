# EmailBison API reference (verified against a live instance, August 2026)

Ground truth: the instance's own OpenAPI spec at `GET {INSTANCE}/api/reference.openapi`. **It returns YAML, not JSON** (`yaml.safe_load`, not `r.json()`). ~143 paths. The public docs site (docs.emailbison.com) is incomplete; when they disagree, the live spec wins. Fetch and cache it at the start of every build.

Auth on every call: `Authorization: Bearer <key>`, `Accept: application/json`, and `Content-Type: application/json` on writes. Instance example: `https://send.yourdomain.com` (load the key by its label from the user's keys file). Retry 429/5xx with backoff.

Pagination: `?per_page=N&page=N`; caps vary by endpoint (lead and campaign-lead listings often cap at 15 regardless of what you ask). Loop to `meta.last_page` always.

## Campaigns

| Call | Notes |
|---|---|
| `GET /api/campaigns` | Paged list. Fields include id, name, status (draft/active/paused/completed), sequence_id, total_leads, max_emails_per_day, open_tracking, plain_text, sequence_prioritization. |
| `POST /api/campaigns` | Body `{"name": str}`. Returns the campaign; status starts `draft`, nothing sends. |
| `GET /api/campaigns/{id}` | Full detail. |
| `PATCH /api/campaigns/{id}/update` | Settings: name, max_emails_per_day, max_new_leads_per_day, daily_max_sends_per_receiving_domain (default 25; set it, usually 3), plain_text, open_tracking, reputation_building, can_unsubscribe, include_auto_replies_in_stats, sequence_prioritization ("followups"\|"new_leads"). Booleans not sent are assumed false on some fields; send explicitly. |
| `PATCH /api/campaigns/{id}/resume` | LAUNCH. Only on explicit user go. |
| `PATCH /api/campaigns/{id}/pause` | Pause. |

## Leads

| Call | Notes |
|---|---|
| `GET /api/leads` | Paged; records include custom_variables[], tags[], status. Single-lead GET also shows lead_campaign_data (campaign membership + per-campaign stats). |
| `GET /api/leads/{id}` | Full record. |
| `POST /api/leads` | CREATE ONLY. 422 "The email has already been taken" if the lead exists. NOT an upsert. |
| `PUT /api/leads/{id}` | FULL REPLACE. Requires email + first_name. Omitted fields (including custom_variables) are CLEARED. Dangerous; prefer PATCH. |
| `PATCH /api/leads/{id}` | Partial update. Only passed fields/variables change. New variable names auto-create on the lead. |
| `POST /api/leads/bulk/csv` | Multipart CSV import that CREATES A NAMED LEAD LIST: `name`, `csv` (file), `existing_lead_behavior` (put\|patch\|skip, defaults to put), `columnsToMap` as one object keyed by field: `columnsToMap[first_name]`, `[last_name]`, `[email]`, `[title]`, `[company]` = the CSV header for each (the array-of-objects shape in the spec is rejected 422). Async: poll `GET /api/lead-lists/{id}` for status Processed, leads_succeeded, leads_failed, error_messages. Custom-variable columns were ignored in testing; set them afterwards with create-or-update/multiple in patch mode. |
| `GET/POST /api/lead-lists`, `GET/PUT /api/lead-lists/{id}` | List, create empty, view (import counters), rename. No delete by API. |
| `POST /api/leads/create-or-update/multiple` | Bulk upsert, max 500/request. `{"existing_lead_behavior": "patch"\|"put", "leads": [...]}`. "patch" = merge (fields not passed kept), "put" = replace (fields not passed CLEARED). **Defaults to "put" if omitted; always pass explicitly.** Personal domains (gmail etc.) skipped unless enabled on the instance. |
| Lead object | email (unique key), first_name, last_name, title, company, notes, custom_variables: `[{"name": str, "value": str}]`. Personal domains are refused unless support enables them on the instance, and the list includes apple.com. |

## Campaign leads

| Call | Notes |
|---|---|
| `GET /api/campaigns/{id}/leads` | Paged (low per_page cap). |
| `POST /api/campaigns/{id}/leads/attach-leads` | `{"lead_ids": [int], "allow_parallel_sending": bool?}`. Chunk at 500. `campaign_id` on lead create/update does NOT attach. Already-attached leads are skipped ("Existing leads were not added"). Active-campaign adds sync within ~5 min. |
| `POST /api/campaigns/{id}/leads/attach-lead-list` | `{"lead_list_id": int}` alternative if a lead list exists. |
| `POST /api/campaigns/{id}/leads/stop-future-emails` | Stop sending to specific leads. |

## Sequence steps

| Call | Notes |
|---|---|
| `GET /api/campaigns/v1.1/{campaign_id}/sequence-steps` | Returns sequence_id + steps with id, active, email_subject, email_body, wait_in_days, order, thread_reply, variant. |
| `POST /api/campaigns/v1.1/{campaign_id}/sequence-steps` | Create from scratch: `{"title": str, "sequence_steps": [{email_subject, email_body, wait_in_days, order, variant, thread_reply, email_subject_variables?, variant_from_step?/variant_from_step_id?}]}`. Required per step: email_subject, email_body, wait_in_days. **wait_in_days is the gap AFTER the step ("days before the sequence moves to the next step"), minimum 1 (0 rejected 422).** For day 0 / 4 / 10: 4, 6, 1. |
| `PUT /api/campaigns/v1.1/sequence-steps/{sequence_id}` | Update: same shape, each step includes its `id`. **Strip `^(Re:\s*)+` from subjects first: Bison re-prefixes "Re: " on thread_reply steps every save, so round-trips accumulate "Re: Re:".** |
| `POST /api/campaigns/sequence-steps/{step_id}/test-email` | Test-send one step. |
| Body conventions | HTML paragraphs `<p>..</p>` with `<p><br></p>` spacers. Merge tags: `{FIRST_NAME}`, `{SENDER_EMAIL_SIGNATURE}`, custom variables as UPPERCASED name in braces: variable "email line 1" -> `{EMAIL LINE 1}`. Spintax `{a|b|c}` in subject/body only, NOT inside variable values. thread_reply: true threads under the previous email (subject then effectively ignored in favor of the thread). |

## Custom variables

| Call | Notes |
|---|---|
| `GET /api/custom-variables` | Workspace registry. A variable must exist HERE for its `{TAG}` to resolve in templates; values stored on leads alone render as literal text. |
| `POST /api/custom-variables` | `{"name": str}`. Register BEFORE the sequence references the tag. |
| `DELETE /api/custom-variables/{id}` | Remove. |

## Sender emails, warmup, signatures

| Call | Notes |
|---|---|
| `GET /api/sender-emails` | Paged. Fields: id, email, type (google_workspace_oauth / microsoft_oauth / imap-smtp), status ("Connected"), daily_limit, warmup_enabled, email_signature. |
| `GET /api/warmup/sender-emails` (+ `/{id}`) | Warmup stats/scores; use to flag bad-warmup mailboxes before attaching. |
| `POST /api/campaigns/{id}/attach-sender-emails` | `{"sender_email_ids": [...]}`. Re-attach returns success:false "already exist" (harmless). |
| `DELETE /api/campaigns/{id}/remove-sender-emails` | Same body. |
| `GET /api/campaigns/{id}/sender-emails` | Who is attached (paged, low cap). |
| `PATCH /api/sender-emails/signatures/bulk` | `{"sender_email_ids": [...], "email_signature": html}`. Async ("could take a few minutes"): verify each with `GET /api/sender-emails/{id}` after. Signature HTML supports spintax and renders via `{SENDER_EMAIL_SIGNATURE}`. |
| `PATCH /api/sender-emails/daily-limits/bulk` | Bulk daily limits. |

## Schedules

| Call | Notes |
|---|---|
| `GET /api/campaigns/schedule/templates` | Saved templates (id, days, start_time, end_time, timezone). |
| `POST /api/campaigns/{id}/create-schedule-from-template` | `{"schedule_id": int}`. |
| `POST /api/campaigns/{id}/schedule` | CREATE (a new campaign has none). Same body as the PUT. Returns 201. |
| `PUT /api/campaigns/{id}/schedule` | UPDATE only. ALL required: monday..sunday booleans, start_time "HH:MM", end_time "HH:MM", timezone (IANA, see `GET /api/campaigns/schedule/available-timezones`), save_as_template. On a campaign with no schedule it returns HTTP 200 with success:false "Schedule does not exist": read back. |
| `GET /api/campaigns/{id}/schedule` | Read back. (`GET .../sending-schedule` exists but 422s without a `day` param; use `/schedule`.) |

## Useful reads for QC and analysis

`GET /api/replies` (paged; from_email_address, interested, automated_reply, text_body), `GET /api/campaigns/{id}/stats`, `GET /api/campaigns/{id}/scheduled-emails`, `GET /api/leads/{id}/sent-emails`, `GET /api/tags`.

## Known error signatures

| Response | Meaning |
|---|---|
| 422 "The email has already been taken." | POST /api/leads on an existing lead; switch to create-or-update or PATCH. |
| 422 "The first name field is required. / email field is required." | PUT /api/leads without the full record; PUT is full-replace. |
| 422 "wait_in_days field must be at least 1." | Step wait of 0. |
| 405 "The POST method is not supported for route..." | Guessed endpoint; check the live spec. |
| success:false "These emails already exist on this campaign" | Sender re-attach; not an error. |
| "Leads successfully added... Existing leads were not added." | Attach dedupe; not an error. |
