# HeyReach API reference (verified against a live workspace, September 2026)

Base `https://api.heyreach.io/api/public`. Every call carries `X-API-KEY: <key>`, `Content-Type: application/json`, `Accept: application/json`. There is no OAuth. Rate limit 300 requests a minute shared across every endpoint; a 429 means back off. Keys are created in the app under Settings, Integrations, and never expire (they can be deactivated).

Documentation state: the public Postman collection (`documenter.getpostman.com/view/23808049/2sA2xb5F75`) documents only the campaign group and its Swagger endpoint redirects in a loop. The list, lead, sender, inbox, webhook and organization groups below come from the open-source `heyreach-cli` project (github.com/bcharleson/heyreach-cli, MIT) and were confirmed against the live API. When a body is uncertain, send a minimal request: the validation error names the fields ("The field LinkedInAccountIds must be ... minimum length of '1'").

Everything is `POST` unless marked. GET endpoints take query strings (`?campaignId=N`). The two lead-removal calls are `DELETE` with a JSON body; POST to them answers 405.

## Auth

| Call | Notes |
|---|---|
| `GET /auth/CheckApiKey` | 200 when the key is valid. First call of every build. |

## LinkedIn senders

| Call | Notes |
|---|---|
| `POST /li_account/GetAll {"offset","limit" (max 100),"keyword"?}` | `items[]`: id, firstName, lastName, emailAddress, profileUrl, isActive, activeCampaigns, authIsValid, isValidNavigator, isValidRecruiter, searchCooldown, connectionRequestCooldown, connectionNoteCooldown, inMailCooldown, accountLimits {followLimit, messageLimit, inMailLimit, profileViewLimit, postLikeLimit, connectioRequestLimit (sic), each with a ...Max}. **Limits are read-only here; the user sets them in the UI ("Set Limits" on the sender).** There is no Premium flag; Sales Navigator and Recruiter are the only license signals. `isActive` false just means no active campaign. |
| `POST /li_account/Connect`, `/li_account/ConnectWithCookies` | Gated behind the "Account Login API" feature; not needed when senders are already connected in the UI. |

## Lists

| Call | Notes |
|---|---|
| `POST /list/GetAll {"offset","limit"}` | `items[]`: id, name, listType (USER_LIST or COMPANY_LIST), totalItemsCount. Check by name before creating: **lists cannot be deleted by API.** |
| `POST /list/CreateEmptyList {"name","type":"USER_LIST"}` | Returns `{"id", ...}`. |
| `POST /list/AddLeadsToListV2 {"listId","leads":[...]}` | Max 100 leads per call. Lead: `profileUrl` (required; vanity or member-id `linkedin.com/in/ACoAA...` both accepted), `firstName`, `lastName`, `companyName`, `position`, `emailAddress`, `location`, `summary`, `about`, `customUserFields: [{"name","value"}]`. Response `addedLeadsCount`, `updatedLeadsCount`, `failedLeadsCount`, `failedLeads`. Same profileUrl again = update, not duplicate. **Send `firstName` and `lastName`:** a lead with only `profileUrl` returns all three counts at 0 and is silently not added (verified Nov 2026). |
| `POST /list/GetLeadsFromList {"listId","offset","limit" (max 100)}` | `totalCount` and `items[]`: id, linkedin_id, profileUrl, firstName, lastName, headline, location, companyName, position, emailAddress, customEmailAddress (the address you uploaded), enrichedEmailAddress, tags, `customFields: [{"name","value"}]`. The walk to verify an upload. |
| `DELETE /list/DeleteLeadsFromListByProfileUrl {"listId","profileUrls":[...]}` | Removes leads; response `{"notFoundInList":[...]}`. **Refused (400) while a running campaign uses the list**, so remove people before the campaign starts. |
| `DELETE /list/DeleteLeadsFromList {"listId","leadMemberIds":[...]}` | Same by `linkedin_id`. |
| `POST /list/GetCompaniesFromList`, `/list/GetListsForLead` | Company lists and reverse lookup; not needed for a people campaign. |

## Leads

| Call | Notes |
|---|---|
| `POST /lead/GetLead {"profileUrl"}` | One stored lead (profile fields, emailEnrichments). The field is `profileUrl`; `linkedInUrl` is rejected. Returns `companyName`, `companyUrl`, `position`, and `experiences` as a JSON **string** of roles (`companyName`, `companyUrl`, `title`, `start`, `end`; a current role has no `end`), sometimes the string `"0"`. After a list add, enrichment usually lands in about 20 seconds; some profiles never enrich from a list alone. Used by the email-linkedin-orchestrator job-change check. |
| `POST /lead/AddTags`, `/lead/ReplaceTags`, `/lead/GetTags` | Tagging; useful for marking test leads. |
| `PATCH /campaign/UpdateLeadCustomFields {"leadMemberIdOrUrl","customFields":{"name":"value",...}}` | Patch variables on a campaign lead in place (object form here, not the array form used on upload). |

## Campaigns

| Call | Notes |
|---|---|
| `POST /campaign/GetAll {"offset","limit"}` | `items[]`: id, name, status (DRAFT, IN_PROGRESS, PAUSED, FINISHED, ...), creationTime, campaignAccountIds. Check by name before creating: **campaigns cannot be deleted by API, only paused.** |
| `GET /campaign/GetById?campaignId=N` | id, name, status, campaignAccountIds, linkedInUserListId, the three exclusion flags, excludeListId, progressStats. **Does not return the schedule.** |
| `POST /campaign/Create` | `{"name" (1 to 50 chars), "linkedInUserListId", "linkedInAccountIds":[ids] (1 to 100, at least one), "excludeContactedFromOtherCampaigns", "excludeHasOtherAccConversations", "excludeContactedFromSenderInOtherCampaign", "excludeListId" (id or null), "schedule":{...}, "sequence":{...}}`. Returns `{"campaignId"}`. Status DRAFT; nothing sends. The list cannot be changed after the campaign is started. |
| `POST /campaign/UpdateSettings {"campaignId","name","linkedInUserListId",exclusion flags,"excludeListId"}` | Rename, swap list, change exclusions. DRAFT, SCHEDULED, PAUSED only. |
| `POST /campaign/UpdateSequence {"campaignId","sequence"}` | Replaces the whole tree. DRAFT, SCHEDULED, PAUSED only (SCHEDULED reverts to DRAFT). Rejects a fallback containing a variable and a tree with a missing END. |
| `POST /campaign/UpdateSchedule {"campaignId","schedule"}` | Replaces the schedule. `startDate` is locked once the campaign has started. |
| `POST /campaign/UpdateAccounts {"campaignId","linkedInAccountIds"}` | Replaces the sender roster. **Empty array is rejected**: a campaign always has at least one sender. |
| `POST /campaign/AddLinkedInAccountsToCampaign` | Adds without replacing. |
| `GET /campaign/GetCampaignSequence?campaignId=N` | The tree as `PublicSequenceNodeDto`; feed it straight back into Create or UpdateSequence on another campaign after dropping the `externalReference` keys the server adds. |
| `POST /campaign/StartCampaign?campaignId=N` | LAUNCH from DRAFT. Only on explicit user go. **The id goes in the query string:** a JSON body `{"campaignId"}` returns 400 "The campaignId field is required" (verified Nov 2026). Returns `{}`; the status reads DRAFT for about 15 seconds, then IN_PROGRESS. |
| `POST /campaign/Pause`, `POST /campaign/Resume` | Resume is for PAUSED; it is rejected on DRAFT. Body vs query-string form UNVERIFIED: StartCampaign needed the query string, so try `?campaignId=N` first. |
| `POST /campaign/AddLeadsToCampaignV2 {"campaignId","accountLeadPairs":[{"lead":{...},"linkedInAccountId"?}],"resumeFinishedCampaign"?,"resumePausedCampaign"?}` | Adds up to 100 leads to a campaign that is IN_PROGRESS (or auto-resumes with the flags). Use it to top up a running campaign; for a new build, put leads in the list instead. |
| `POST /campaign/GetLeadsFromCampaign {"campaignId","offset","limit","timeFrom"?,"timeTo"?,"timeFilter"?}` | Per-lead status inside the campaign. |
| `POST /campaign/StopLeadInCampaign {"campaignId","leadMemberId","leadUrl"}` | Stop one person. Returns 200 with an empty body on a started lead, which then shows as `Paused` in GetLeadsFromCampaign and counts in `totalUsersManuallyStopped`. **Returns 500 on a lead still Pending** (not yet picked up by the campaign); the API cannot remove those. |
| `POST /campaign/GetCampaignsForLead {"profileUrl","offset","limit"}` | Reverse lookup: every campaign a person is in, with `leadStatus` (Pending, InSequence, ...). |
| `POST /campaign/CreateCampaignFromTemplate` | Clone from a saved template. |

### Schedule object

```json
{"dailyStartTime": "09:00:00", "dailyEndTime": "18:00:00", "timeZoneId": "America/Chicago",
 "enabledMonday": true, "enabledTuesday": true, "enabledWednesday": true, "enabledThursday": true,
 "enabledFriday": true, "enabledSaturday": false, "enabledSunday": false,
 "startDate": "2026-09-10", "endDate": null}
```

IANA time zone ids. Dates are ISO or null.

### Sequence tree

A node: `nodeType`, `actionDelay` (integer), `actionDelayUnit` ("HOUR" or "DAY"), optional `payload`, optional `conditionalNode` (the yes branch), optional `unconditionalNode` (the no branch, or the next step for unconditional nodes). The implicit START is not written. Every path must end in an `END` node, and END nodes carry a delay (the validator has rejected missing or zero delays on the root request and on END nodes; use at least 3 HOUR).

| nodeType | payload | Branches |
|---|---|---|
| `CHECK_IS_CONNECTION` | none | conditional = already connected, unconditional = not connected |
| `CHECK_IS_OPEN_PROFILE` | none | conditional = open profile (InMail is free), unconditional = not |
| `CONNECTION_REQUEST` | `messages` (list of note variants, rotated; `[]` for a blank request), `fallbackMessage` (plain text, `""` for blank), `toBeWithdrawnAfterDays` (default 30) | conditional = accepted, unconditional = not accepted by the time that branch's delay elapses |
| `MESSAGE` | `messages` (variants), `fallbackMessage` | unconditional = next step; conditional is present in UI-built trees (an END) and can be ignored |
| `INMAIL` | `messages: [{"subject","message"}]`, `fallbackMessage: {"subject","message"}` | unconditional = next. Needs Premium credits or an open profile |
| `VIEW_PROFILE`, `FOLLOW`, `LIKE_POST`, `FIND_EMAIL` | none | unconditional = next |
| `SEND_LEAD_TO_BISON` | `bisonCampaignId`, `stopExternalLead` | hands the lead to an EmailBison campaign; `SEND_LEAD_TO_INSTANTLY` and `SEND_LEAD_TO_SMARTLEAD` likewise |
| `END` | none | terminal |

Variables inside `messages`: single braces. Custom `{first_name}`, `{connection_note}`; built-in `{FIRST_NAME}`, `{LAST_NAME}`. Custom names are letters, digits and underscores only. **Fallbacks may not contain variables** (400 "The fallback message is invalid in the ... action"). **An empty variable value makes the whole step fall back**, so people with and without a note need separate campaigns. Message length up to 8000 characters; connection notes 300 on Premium and Sales Navigator, 200 on free accounts.

## My network (who is already connected)

| Call | Notes |
|---|---|
| `POST /MyNetwork/GetMyNetworkForSender {"senderId","pageNumber","pageSize"}` | One sender's 1st-degree connections. `pageNumber` starts at 0; `pageSize` must be under 100 (99 works). Returns `totalCount` and `items[]`: profileUrl, linkedin_id (numeric), firstName, lastName, companyName, position, headline, location. About 20% of entries carry a member-id URL (`/in/ACoAA...`), so match leads by `linkedin_id` as well as by URL. |
| `POST /MyNetwork/IsConnection {"senderAccountId","leadProfileUrl"}` or `{"senderAccountId","leadLinkedInId"}` | `{"isConnection": true}` or `false` for one lead and one sender. Good for spot checks. |

Campaign leads carry `leadConnectionStatus` (None, ConnectionSent, ConnectionAccepted) in `GetLeadsFromCampaign`. A lead in a sender's network whose status is `ConnectionAccepted` connected through the campaign; one with any other status was connected before it. The sequence's `CHECK_IS_CONNECTION` node tests only the sender the lead is assigned to, not every sender on the campaign.

## Inbox, webhooks, stats, organization

| Call | Notes |
|---|---|
| `POST /inbox/GetConversationsV2`, `/inbox/GetChatroom`, `/inbox/SendMessage`, `/inbox/ChatroomSetSeen` | Unified inbox; reply handling belongs to another skill. |
| `POST /webhooks/CreateWebhook {"webhookName","webhookUrl","eventType","campaignIds"}` and Get/Update/Delete | Event types: CONNECTION_REQUEST_SENT, CONNECTION_REQUEST_ACCEPTED, MESSAGE_SENT, MESSAGE_REPLY_RECEIVED, INMAIL_SENT, INMAIL_REPLY_RECEIVED, EVERY_MESSAGE_REPLY_RECEIVED, FOLLOW_SENT, LIKED_POST, VIEWED_PROFILE, CAMPAIGN_COMPLETED, LEAD_TAG_UPDATED. Prefer webhooks to polling given the shared rate limit. |
| `POST /stats/GetOverallStats {"accountIds","campaignIds","startDate","endDate"}` | Day-by-day sends, accepts, replies, acceptance and reply rates. |
| `POST /organization/...` | Workspaces, users, API keys; agency admin only. |

## Behaviours to plan around

- **Enrichment on import.** HeyReach looks every uploaded profile up on LinkedIn and overwrites `firstName`, `lastName`, `companyName`, `position`, `location` and `profileUrl` with what it finds. Member-id URLs become vanity URLs. Your normalized names survive only inside custom variables.
- **Duplicates on re-upload.** Because the stored URL changes, re-sending a lead under its original URL adds a second record. Walk the list, map `customEmailAddress` to the current `profileUrl`, and re-send with that. Match to the source CSV by email, never by URL.
- **Read-back timing.** A list walk immediately after a large update can still show the previous values on a few rows; wait 30 seconds before the QC walk.
- **The UI is the user's editor.** Trees, fallbacks, greetings and delays change there between calls. Always GET before UpdateSequence, and treat the UI version as the template when asked to replicate it.

## Known error signatures

| Error | Cause | Fix |
|---|---|---|
| `The fallback message is invalid in the "Connection request" action` / `... in a "Send Message" action` | A variable inside `fallbackMessage` | Plain-text fallbacks |
| `The field LinkedInAccountIds must be a string or array type with a minimum length of '1'` | UpdateAccounts or Create with no senders | Attach at least one; remove in the UI if the user wants none |
| `Node 'CONNECTION_REQUEST' at sequence root has invalid delay: 00:00:00. Set actionDelay >= 3 and actionDelayUnit = 'HOUR'` | Missing or zero delay on the root request or an END node | Set delays on every node |
| `The ProfileUrl field is required` on `/lead/GetLead` | Wrong field name (`linkedInUrl`) | Use `profileUrl` |
| 405 on `/list/DeleteLeadsFromList...` | Sent as POST | Send as DELETE with the JSON body |
| `The list you selected cannot be currently modified because it is used by a running campaign.` | List delete while its campaign is running | Remove people before the campaign starts; for started leads use StopLeadInCampaign |
| 500 `An unexpected error occurred` on `/campaign/StopLeadInCampaign` | The lead is still Pending in the campaign | Cannot be done by API; the user removes the lead in the UI |
| `PageSize must be positive number less than 100` | `pageSize` 100 or more on `/MyNetwork/GetMyNetworkForSender` | Use 99 |
| `Only one of the following parameters should be provided: leadLinkedInId or leadProfileUrl` | Both sent to `/MyNetwork/IsConnection` | Send one; prefer `leadLinkedInId` when the lead has it |
| 429 | Over 300 requests a minute | Sleep and retry; batch lead uploads at 100 |
