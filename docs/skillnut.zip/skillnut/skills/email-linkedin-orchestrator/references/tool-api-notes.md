# Tool API notes (verified behaviour)

Everything marked **verified** was called against live accounts in the reference build (November 2026). Anything not marked is from the vendor's docs and must be tested read-only first. The full HeyReach reference lives in the email-and-linkedin-sequencer-lead-upload skill (`references/heyreach-api.md`); this file holds only what the bridge depends on.

## Salesloft (email cadence)

Auth: Header Auth, `Authorization: Bearer <key>`. Rate limit header `x-ratelimit-limit-minute: 600`.

| Call | Behaviour |
|---|---|
| `GET /v2/actions?type=integration&per_page=100&page=N` | Open tasks. LinkedIn steps are `type: integration`. **Verified:** `due` is a boolean ("due now"), `due_on` is the date. The `user_id` filter is **ignored** on this endpoint: group by `action.user.id` yourself. |
| `GET /v2/cadences?per_page=100` | `cadence_function` (outbound, inbound, event, other), `archived_at`. |
| `GET /v2/action_details/integration_details/{id}` | The step's instruction text. Verified unusable as copy in the reference build (broken characters, internal notes, stale dates). |
| `GET /v2/people/{id}` | `first_name`, `last_name`, `email_address`, `person_company_name`, `title`, `linkedin_url` (usually empty). |
| `GET /v2/people?email_addresses[]=<email>` | **Verified** exact match. |
| `GET /v2/activities/emails?per_page=100&person_id=<id>` | Sent emails with `cadence.id`, `sent_at`. **Verified:** adding sort params returned 0 rows; leave them off and sort client-side. |
| `GET /v2/mime_email_payloads/{email_id}` | **Verified:** `data.raw` is base64 of the full MIME message; the text/plain part is quoted-printable; cp1252 characters and U+FFFD appear. Decoder in `bridge-workflow.md`. |
| `POST /v2/activities {"action_id": <id>}` | **Verified** on 20 tasks: 201 Created, body `{data:{updated_at}}`, and the task leaves the open list. This is how the bridge closes the LinkedIn step. |
| `GET /v2/cadence_memberships?person_id=<id>` | `currently_on_cadence`, `current_state`. **Verified.** |
| `DELETE /v2/cadence_memberships/{id}.json` | Removes from the cadence (used by the reply sync and by the partner stop). |

## HeyReach (LinkedIn)

Auth: Header Auth, `X-API-KEY`.

| Call | Behaviour |
|---|---|
| `POST /campaign/Create` | Creates in DRAFT with list, senders, schedule, sequence, exclusion toggles. Cannot be deleted later. **Verified.** |
| `POST /campaign/StartCampaign?campaignId=<id>` | **Verified:** the id must be in the query string; a JSON body returns 400 "The campaignId field is required". Returns `{}`; status reads DRAFT for about 15 seconds, then IN_PROGRESS. |
| `POST /list/AddLeadsToListV2` | **Verified:** a lead with only `profileUrl` returns `addedLeadsCount: 0, failedLeadsCount: 0` (silent no-op). Send `firstName` and `lastName` too. Same URL again counts as `updatedLeadsCount`. |
| `POST /campaign/AddLeadsToCampaignV2` | Adds to an IN_PROGRESS campaign with `accountLeadPairs[{linkedInAccountId, lead}]`. **Verified** for the rep campaign. |
| Custom variables | Written as `customUserFields: [{name, value}]`; **read back as `customFields`**. Variables in the sequence are single braces `{li_msg_1}`. An empty variable sends the fallback; fallbacks may not contain variables. |
| Enrichment | HeyReach overwrites firstName, lastName, companyName, position with the profile's own values (a first name of "Jane PharmD", a last name of "Doe, MD, Neurologist."). Keep your clean first name inside the message variable. |
| `POST /lead/GetLead {"profileUrl"}` | **Verified:** `companyName`, `companyUrl` (company page slug, sometimes a different entity than `companyName`), `position`, `experiences` as a **JSON string** of roles (`companyName`, `companyUrl`, `title`, `start`, `end`; current roles have no `end`); sometimes the string `"0"`. Enrichment after a list add took about 20 seconds; some profiles never enriched from a list alone (still empty after 40 minutes). |
| `POST /campaign/GetCampaignsForLead` | By `profileUrl` or `email`: `campaignId`, `campaignName`, `campaignStatus`, `leadStatus` (Pending, InSequence, InProgress, Paused, Finished). No profile URL in the response. |
| `POST /campaign/StopLeadInCampaign {campaignId, leadUrl}` | **Verified:** 200, empty body; the lead then shows `Paused`. Pending leads return 500. |
| `POST /blacklist/AddLeads` | Workspace-wide: blocks the person in every campaign, including the bridge's. |
| `DELETE /list/DeleteLeadsFromListByProfileUrl` | Refused while a running campaign uses the list. |
| `POST /webhooks/GetAllWebhooks` | Shows each webhook's `eventType` and `campaignIds`; `[]` means all campaigns. |
| `POST /campaign/Pause?campaignId=<id>`, `/campaign/Resume?campaignId=<id>` | **Verified** with the query string; both return `{}` and the status changes within seconds. Pause, then `DeleteLeadsFromListByProfileUrl`, then Resume removes a **Pending** lead from a running campaign; the lead then shows `Failed` in that campaign. |
| Rate limit | **Verified:** 24 unthrottled adds in one burst returned 429 for half of them. Batch HeyReach writes at 2 per 2 seconds. With Never Error on, a 429 is not retried, so only close the email-tool task for adds that returned 200; the rest stay open and the next run retries them. |

Reply webhook payload: `campaign {id, name, status}`, `sender {id, ...}`, `lead {id, profile_url, first_name, last_name, company_name, position, email_address, enriched_email, custom_email, lists[]}`, `recent_messages` or `recent_inmails` (`message`, `is_reply`, `creation_time`), `event_type` (`message_reply_received`, `inmail_reply_received`).

## Email Bison (other email tool)

| Call | Behaviour |
|---|---|
| `GET /api/leads/{email}` | `data.id`, `data.lead_campaign_data[{campaign_id, status}]`. Not found returns an error body. |
| `POST /api/campaigns/{id}/leads/stop-future-emails {"lead_ids":[id]}` | Pauses that lead in that campaign (`stopped`). Prefer this to unsubscribe. |

## HubSpot (LinkedIn URLs)

`GET /crm/v3/objects/contacts/{email}?idProperty=email&properties=hs_linkedin_url,firstname,lastname`. In the reference build 44 of 45 due people had `hs_linkedin_url`. Normalise to `https://www.linkedin.com/in/<slug>` before use.

## Claude API (rewrite)

n8n HTTP Request with the `anthropicApi` credential, `POST https://api.anthropic.com/v1/messages`. Use the current model and API version. Read the text from content blocks of `type: text`, and treat `stop_reason: refusal` as a skip. About 10 rewrites take under 20 seconds at low effort.

## Missing LinkedIn URLs: Clay waterfall (preferred)

**Verified:** Clay-managed table function **"Person LinkedIn URL"** is a 10-provider waterfall: LiveData, People Data Labs, Companies People Jobs, Reverse Contact, MixRank, Snov.io, Datagma, Champify, LeadMagic, Bytemine. It costs about 4.1 credits per person.
- **Make it callable:** it is not a routine by default. Register it once with `clay routines create function <tableId> --name "..." --entity-type contact`. Find the table ID with `clay workflows actions search "linkedin profile url waterfall"`.
- **Inputs:** `Full name` (required), `Company name`, `Company domain`, `Work email`, `Personal email`. Most steps read `Personal email`, so pass the work email in both.
- **Call:** Public API, header `clay-api-key`. Start with `POST https://api.clay.com/public/v0/routines/function:<tableId>/run {"items":[{"id","inputs"}]}`, which returns 202 and `routine_run_id`. Read results with `GET /routines/run/<run>/results?limit=100`; each item is `{id, status, result: {"LinkedIn URL"}}`.
- **Speed:** one person completed in 8 seconds. In n8n, start one run for everyone, wait about 40 seconds, then read the results.
- **Workspace settings:** `GET /me` and `GET /credits/balance` confirm the key, the workspace and the credits.

## Missing LinkedIn URLs: Claude web search (fallback when the client has no enrichment tool)

When neither the email tool nor the CRM has a URL, call Claude with the web search tool (`web_search_20260209`, `max_uses` about 4). Give it the name, title, company and email domain, and tell it to return only `https://www.linkedin.com/in/<slug>` or NONE. **Verified:** it found the right profile with one search. Never trust the answer alone: put the URL through the job-change list and accept it only if the enriched profile's last name matches. Then save it back to the email tool (Salesloft `PUT /v2/people/{id}.json {"linkedin_url"}`). An enrichment vendor (Clay, People Data Labs and others) works the same way if the client has a working key. In the reference build, the Clay key in the client's keys file returned 401 on every Clay API.

## Slack

Slack node, post to a user (DM) by member ID, `onError: continueRegularOutput` so a Slack hiccup never fails the run.

## Untested tools: starting points

| Tool | Where the LinkedIn step lives | Close the step | Notes |
|---|---|---|---|
| Outreach | Tasks API, task type for LinkedIn | Mark task complete | Sequence states per prospect |
| Apollo | Tasks with LinkedIn step types | Complete task | Emailer messages per contact |
| HubSpot Sequences | Tasks created by the sequence | Complete task | Sequence enrollments API |
| Expandi | Campaign contacts with placeholders | n/a | Check whether per-contact variables are supported |
| La Growth Machine | Audiences and leads with custom attributes | n/a | Multichannel itself; often only the LinkedIn part is used |

All UNVERIFIED. Read the current docs, then test read-only, then one write on one record.
