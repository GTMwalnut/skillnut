Skillnut Free: one zip per skill, for the free Claude plan.

In Claude.ai: Customize > Skills > + > Upload a skill, once for each zip in this folder.
On a paid Claude plan, use skillnut-free.zip instead: one upload installs them all.
