# Skillnut Free

A guide plus 7 GTM skills by GTM Walnut: ICP, cold call openers, events, CRM data, a GTM dashboard, training docs and LinkedIn posts.

## Install

- **Claude Code, Cursor, Codex or any agent that reads SKILL.md:** `npx skills add gtmwalnut/skillnut`
- **Claude.ai or Claude Desktop (Pro, Max, Team or Enterprise):** download `skillnut-free.zip` from https://skills.gtmwalnut.com, then Customize > Plugins > Add > Upload plugin. One file, every skill.
- **Free Claude plan:** download `skillnut-free-one-by-one.zip` from https://skills.gtmwalnut.com, unzip it, and upload each skill under Customize > Skills.
